package ejemploInterface1;

public interface Machine {
	
	public String suena();
	public void reset();
	
}
