package practica6bis;

import java.util.*;

public class Ej3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		double precio, pago, devo, div500, div200, div100, div50, div20, div10, div5, div2, div1;
		
		System.out.println("Cúanto cuesta el artículo: ");
		precio=sc.nextDouble();
		
		System.out.println("Cúanto dinero he recibido del cliente: ");
		pago=sc.nextDouble();
		
		
		
	}

}
