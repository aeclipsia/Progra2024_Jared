package practica7;

import java.util.*;

public class Ej5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		char d;
		int edad;
		double precio;
		
		System.out.println("Qué día es hoy? ");
		System.out.println("L,M,X,J,V,S,D");
		d=sc.next().charAt(0);
		d=Character.toUpperCase(d);
		
		switch (d) {
		case 'L':
		case 'J':
		case 'V':
			
			break;

		default:
			break;
		}
		
	}

}
