package ejemplos;

public class if_ej {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int nota=10;
		
		
		if (nota>=5) {
			System.out.println("Ha aprobado");
		}
		else {
			System.out.println("ha suspendido");
		}
	}

}
