package buenoJared2Eval;

/*
 * @author Jared James Lloyd Bueno
 */

public class ArregloNoInicializadoException extends Exception{

	public ArregloNoInicializadoException() {
		
	}
	
	public ArregloNoInicializadoException(String message) {
		super(message);
	}
}
