package buenoJared2Eval;

/*
 * @author Jared James Lloyd Bueno
 */

public class ArregloNoEncontradoException extends Exception{

	public ArregloNoEncontradoException() {
		
	}
	
	public ArregloNoEncontradoException(String message) {
		super(message);
	}
}
