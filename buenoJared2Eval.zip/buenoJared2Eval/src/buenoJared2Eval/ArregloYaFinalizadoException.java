package buenoJared2Eval;

/*
 * @author Jared James Lloyd Bueno
 */

public class ArregloYaFinalizadoException extends Exception{

	public ArregloYaFinalizadoException() {
		
	}
	
	public ArregloYaFinalizadoException(String message) {
		super(message);
	}
}
