package buenoJared2Eval;

public class NoHayPendientesException extends Exception{

	public NoHayPendientesException() {
		
	}
	
	public NoHayPendientesException(String message) {
		super(message);
	}
}
