package ejercicio5;

import java.util.Scanner;

public class Main_Alquiler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Alquiler vehiculos[] = new Alquiler[3];
		int contVeh = 0, pos, opc = 0;
		String matricula, modelo, marca;
		int añoMatriculacion = 0, categoria = 0, dias = 0, tipo = 0;
		boolean validaMatricula = false;
		String hacer = "";
		double importe;

		for (int i = 0; i < vehiculos.length; i++) {
			vehiculos[i] = creaAlquiler(sc);
		}

		do {

			System.out.println("1.Introduza si desea alquilar\n2.Devolver\n3.Mostrar\n4.salir");
			opc = sc.nextInt();
			switch (opc) {

			case 1:
				sc.nextLine();
				System.out.println("Anota matricula:");
				matricula = sc.nextLine();
				pos = buscarMatricula(vehiculos, matricula);
				if (pos == -1) {
					System.out.println("La matrícula no existe");

				} else {
					System.out.println("Anote dias");
					dias = sc.nextInt();

					importe = vehiculos[pos].alquiler(dias);
					if (importe == 0)
						System.out.println("No se ha podido alquilar");
					else
						System.out.println("Vehiculo alquilado por " + importe + " euros");
				}

				break;

			case 2:

				sc.nextLine();
				System.out.println("Anota matricula:");
				matricula = sc.nextLine();
				pos = buscarMatricula(vehiculos, matricula);
				if (pos == -1) {
					System.out.println("La matrícula no existe");

				}
				else

					vehiculos[pos].devolver();

				break;

			case 3:
				System.out.println("Información de todos los vehiculos:");
				for (int i = 0; i < vehiculos.length; i++) {
					System.out.println(vehiculos[i].toString());
				}

			}

		} while (opc != 4);

		System.out.println("Vehiculos alquilados " + Alquiler.getVehAlquilado());
		System.out.println("Ganancias Totales " + Alquiler.getGanancias());

	}

	public static boolean matriculaValida(String matricula) {
		// cuidado aqui en la longitud poner o en vez de y ya que no pueden cumplirse
		// las dos condiciones a la vez
		String letras;
		letras = matricula.substring(4);
		letras = letras.toUpperCase();

		if (matricula.length() != 7) {
			return false;
		}

		for (int i = 4; i < letras.length(); i++) {
			if (letras.charAt(i) < 'A' || letras.charAt(i) > 'Z') {
				return false;
			}
		}

		for (int i = 0; i <= matricula.length() - 4; i++) {
			if (matricula.charAt(i) < '0' || matricula.charAt(i) > '9') {
				return false;
			}
		}

		return true;
	}

	public static Alquiler creaAlquiler(Scanner sc) {
		String matricula, modelo, marca;
		boolean validaMatricula;
		int añoMatriculacion, categoria;

		do {

			System.out.println("Escribe la matricula del vehiculo");
			matricula = sc.nextLine();

			validaMatricula = matriculaValida(matricula);

			if (validaMatricula == false)
				System.out.println("Matricula no valida, vuelva a introducir una nueva");
		} while (validaMatricula != true);

		System.out.println("Escribe el modelo del vehiculo");
		modelo = sc.nextLine();

		System.out.println("Escribe la marca del vehiculo");
		marca = sc.nextLine();

		System.out.println("Escribe el año de matriculacion del vehiculo");
		añoMatriculacion = sc.nextInt();

		System.out.println("Escribe la categoria del vehiculo (1,2)");
		categoria = sc.nextInt();
	

		Alquiler a = new Alquiler(matricula, modelo, marca, añoMatriculacion, categoria);
		return a;
	}

	static public int buscarMatricula(Alquiler vehiculos[], String mat) {

		for (int i = 0; i < vehiculos.length; i++) {
			if (mat.equalsIgnoreCase(vehiculos[i].getMatricula()))
				return i;
		}
		return -1;
	}

}
