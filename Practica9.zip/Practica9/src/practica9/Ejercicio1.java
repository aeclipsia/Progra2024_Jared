package practica9;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numeros[]=new int[10];
		
		Scanner sc=new Scanner(System.in);
		
		for(int i=0;i<numeros.length;i++) {
			System.out.println("Anota número:");
			numeros[i]=sc.nextInt();
		}
		
		System.out.println("Los números pares son:");
		for(int i=0;i<numeros.length;i++) {
			if (numeros[i]%2==0)
				System.out.println(numeros[i]);
			
		}
		
		System.out.println("Los números impares son:");
		for(int i=0;i<numeros.length;i++) {
			if (numeros[i]%2!=0)
				System.out.println(numeros[i]);
			
		}

	}

}
